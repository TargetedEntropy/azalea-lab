Azalea Bot - Server Patches for NeoForge 21.1.219
==================================================

These patches allow a non-NeoForge client (Azalea Rust bot) to connect
to a NeoForge 1.21.1 server. Without them, NeoForge rejects any client
that doesn't speak the full mod channel protocol.

Tested with DynamicOdyssey modpack versions 2.7.0 through 2.26.0
(100 to 328 mods).


WHAT'S INCLUDED
---------------

1. checkpatch-coremod-1.0.0.jar  (drop-in mod)
2. NegotiationPatch.java          (compile & inject)
3. ConfigInitPatch.java            (compile & inject)


STEP 1: Drop-in Coremod (easy)
-------------------------------

Copy checkpatch-coremod-1.0.0.jar into your server's mods/ folder.

This patches NetworkRegistry.checkPacket() at runtime via ASM bytecode
transformation, preventing UnsupportedOperationException when mods send
custom payloads to a non-NeoForge client.

No compilation needed — just drop the JAR into mods/ and restart.


STEP 2: Compile & Inject Java Patches
--------------------------------------

These two patches replace classes inside the NeoForge universal JAR.
They must be compiled against the server's classpath and injected with
`jar uf`.

  # 1. Find your NeoForge universal JAR:
  NEOFORGE_JAR=libraries/net/neoforged/neoforge/21.1.219/neoforge-21.1.219-universal.jar

  # 2. Set up the source files in the correct package paths:
  mkdir -p /tmp/patch/net/neoforged/neoforge/network/negotiation
  mkdir -p /tmp/patch/net/neoforged/neoforge/network
  cp NegotiationPatch.java /tmp/patch/net/neoforged/neoforge/network/negotiation/NetworkComponentNegotiator.java
  cp ConfigInitPatch.java  /tmp/patch/net/neoforged/neoforge/network/ConfigurationInitialization.java

  # 3. Build the classpath from all server library JARs:
  CP=$(find libraries -name "*.jar" | tr "\n" ":")

  # 4. Compile:
  javac -proc:none -cp "$CP" \
    /tmp/patch/net/neoforged/neoforge/network/negotiation/NetworkComponentNegotiator.java \
    /tmp/patch/net/neoforged/neoforge/network/ConfigurationInitialization.java

  # 5. Inject into the NeoForge JAR:
  cd /tmp/patch
  jar uf /path/to/$NEOFORGE_JAR \
    net/neoforged/neoforge/network/negotiation/NetworkComponentNegotiator.class \
    "net/neoforged/neoforge/network/negotiation/NetworkComponentNegotiator\$ComponentNegotiationResult.class" \
    net/neoforged/neoforge/network/ConfigurationInitialization.class

  # 6. Restart the server.


WHAT EACH PATCH DOES
--------------------

NegotiationPatch.java
  Replaces NetworkComponentNegotiator.negotiate() to always return
  success with an empty component list. Bypasses NeoForge channel
  negotiation that would reject non-NeoForge clients.

ConfigInitPatch.java
  Replaces ConfigurationInitialization to skip three checks that fail
  for non-NeoForge clients:
    - RegistryDataMapNegotiation (mod registry sync)
    - CheckExtensibleEnums (extensible enum validation)
    - CheckFeatureFlags (feature flag verification)
  Still runs SyncRegistries, CommonVersionTask, CommonRegisterTask,
  and SyncConfig for clients that support them.

checkpatch-coremod-1.0.0.jar
  ASM coremod that replaces the body of NetworkRegistry.checkPacket()
  with a RETURN instruction, making it a no-op. Prevents disconnection
  when mods send payloads the bot doesn't understand.


IMPORTANT NOTES
---------------

- These patches are built against NeoForge 21.1.219 class signatures.
  If your server uses a different NeoForge version, the Java patches
  may need updating (you'll see compilation errors).

- The coremod (checkpatch-coremod-1.0.0.jar) targets a method by name
  and should work across minor NeoForge updates unless the method
  signature changes.

- The server must run in offline mode (online-mode=false) since the
  bot uses an offline account.
